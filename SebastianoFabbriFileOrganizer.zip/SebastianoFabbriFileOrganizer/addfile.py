# 'os' per interagire con i file di sitema
# 'csv' per creare file csv dove inserire i dati
# 'shutil' per spostare file
# 'argparse' per l'interfaccia a linea di comando (CLI)
import os, csv, shutil, argparse

def main():
    # descrizione del programma 
    parser = argparse.ArgumentParser(description='auto move file in specific directory')

    # aggiungo l'argomento da utilizzare, viene convertito in stringa e scrivo una descrizione ulteriore in caso di aiuto 
    parser.add_argument('f', type=str,
                        help='insert file with extension to move file in specific directory. File must be inside work directory')
    
    # assegno l'argomento ad una variabile
    args = parser.parse_args()

    # chiamo la funzione con il suo argomento
    moveFile(args)

# dichiaro una funzione che ha come unico argomento il file da spostare 
def moveFile(args):
    # mi sposto nella cartella in cui ci sarà il file da spostare
    pathDir = r'   ---INSERIRE PATH DIRECTORY\SebastianoFabbriFileOrganizer\files (inside single quotes)---   '
    os.chdir(pathDir)

    # dichiaro i percorsi delle cartelle in cui andranno i file in base all'estensione
    pathAudio = pathDir + '\\audio'
    pathDocs = pathDir + '\\docs'
    pathImages = pathDir + '\\images'
    
    # separo nome, estensione e dimensione, in modo da inserire i dati nel file .csv
    fileName = args.f.split('.')[0]
    ext = args.f.split('.')[-1]
    sizeFile = os.path.getsize(pathDir + '\\'+ args.f)

    # in base all'estensione, muovo il file nella cartella specifica. Se l'estensione è diversa da quelle supportate, appare un messaggio in automatico e l'eseguibile si ferma
    if ext == 'mp3':
        shutil.move(pathDir + '\\' + args.f, pathAudio)
        print(args.f + " has moved to directory audio")
    elif ext == 'txt' or ext == 'odt':
        shutil.move(pathDir + '\\' + args.f, pathDocs)
        print(args.f + " has moved to directory docs")
    elif ext == 'png' or ext == 'jpeg' or ext == 'jpg':
        shutil.move(pathDir + '\\' + args.f, pathImages)
        print(args.f + " has moved to directory images")
    else:
        print("estensione non supportata")
        return
    
    # aggiorno il file .csv con il nome, estensione e dimensione del file
    with open('recap.csv', 'a', newline='') as f:
        fieldnames = ["name", "type", "size(B)"]
        data_append = csv.DictWriter(f, fieldnames=fieldnames)
        data_append.writerow({"name":fileName, "type":ext, "size(B)":str(sizeFile)})

if __name__ == "__main__":
    main()